import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IUser } from 'src/app/models/user';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    userId: String = null;
    user_API_URL = "http://localhost:1000/IUser/";


    constructor(
        private httpClient: HttpClient
    ) {

    }

    setCurrentUserId(id) {
        this.userId = id;
    }

    getCurrentUserId() {
        return this.userId;
    }

    registerUser(user: IUser) {
        return this.httpClient.post<IUser>(this.user_API_URL, user);
    }

    getRegisteredUser(id: String) {
        return this.httpClient.get<IUser>(this.user_API_URL + id);
    }

    getUserByID(id: string) {
        return this.httpClient.get<IUser>(this.user_API_URL + id)
    }
}