import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IProduct } from 'src/app/models/products';
import { FormGroup } from '@angular/forms';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class ProductService {
  product_API_URL = "http://localhost:3000/IProducts/";
  id: string;


  setCurrentProductId(id) {
    localStorage.setItem("currentProductId", id);
  }

  getCurrentProductId() {
    return localStorage.getItem("currentProductId");
  }

  constructor(private httpClient: HttpClient) { }

  getProducts() {
    return this.httpClient.get<IProduct[]>(this.product_API_URL);
  }

  getProductByID(id: string) {
    return this.httpClient.get<IProduct>(this.product_API_URL + id);
  }

  addProduct(product: IProduct) {
    return this.httpClient.post<IProduct>(this.product_API_URL, product);
  }

  updateProduct(id: string, formGroup: FormGroup) {
    return this.httpClient.put<IProduct>(this.product_API_URL + id, formGroup);
  }

  deleteProduct(id: string) {
    return this.httpClient.delete<IProduct>(this.product_API_URL + id);
  }

  updateProdViewDetails(id: string, product: IProduct) {
    return this.httpClient.put<IProduct>(this.product_API_URL + id, product);
  }

}
