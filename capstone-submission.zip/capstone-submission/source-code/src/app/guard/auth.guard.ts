import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UserService } from '../services/user/user.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {

  constructor(
    private router: Router,
    private userService: UserService
  ) { }

  canActivate(): boolean {
    console.log("Can activate guard : " + localStorage.getItem("isLoggedIn"))

    if (localStorage.getItem("isLoggedIn") === "true") {
      return true;
    }
    else {
      let result: boolean = confirm("Login is required to perform this operation. Do you want to continue?")
      if (result) {
        this.router.navigate(['login']);
        return false;
      }
      else {
        return;
      }
    }
  }
}
