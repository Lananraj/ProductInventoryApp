export interface IProduct{
    id : String ;
    prodName : String ;
    prodDescription : String ;
    prodManufact : String;
    prodPrice : number ;
    prodQuantity : number ;
    viewCount : number ;
}