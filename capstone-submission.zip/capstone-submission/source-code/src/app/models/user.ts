export interface IUser{
    id : String;
    username : String;
    password : String;
    firstName : String;
    lastName : String;
    location : String;
    mobileNo : number ;
}