import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IUser } from '../models/user';
import { UserService } from '../services/user/user.service';


@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']

})
export class LoginComponent implements OnInit {


  loginForm: FormGroup;
  submitted = false;
  loginUserDetails: IUser;
  loginErrMsg: string = null;

  @Output() navBarFlag = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService
  ) {

  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });

  }

  get loginFormItems() {
    return this.loginForm.controls;
  }
  onSubmit() {
    this.submitted = true;
    this.loginErrMsg = null;


    if (this.loginForm.invalid) {
      return;
    }

    let userid = this.loginForm.controls['username'].value;
    let userPassword = this.loginForm.controls['password'].value;

    this.userService.getUserByID(userid).subscribe(
      res => {
        this.loginUserDetails = res;
        if (this.loginUserDetails.password === userPassword) {
          localStorage.setItem("isLoggedIn", "true");
          this.userService.setCurrentUserId(userid);
          localStorage.setItem("currentUserId", userid);

          this.router.navigate(['products']).then(() =>
            location.reload()
          )
        }
        else {
          this.loginErrMsg = "Password does not match";
        }
      },
      err => {
        this.loginErrMsg = "User id does not exists";
      }
    )
  }

  setNavbarFlag() {
    this.navBarFlag.emit(true);
  }

}
