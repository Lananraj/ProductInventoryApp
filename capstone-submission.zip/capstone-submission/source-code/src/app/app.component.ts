import { Component, OnInit, ComponentFactoryResolver } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './services/user/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  navBarFlag: boolean = false;
  title = 'prod-inventory-app';

  constructor(private router: Router,
    private userService: UserService
  ) {

    if (localStorage.getItem("isLoggedIn") === "true") {
      this.navBarFlag = true;
    }
  }

  logout() {
    this.navBarFlag = false;
    localStorage.clear();
    location.reload();
  }


  ngOnInit() {
    if (localStorage.getItem("isLoggedIn") === "true") {
      this.navBarFlag = true;
    }
  }


}
