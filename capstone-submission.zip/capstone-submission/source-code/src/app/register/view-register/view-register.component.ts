import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user/user.service';
import { IUser } from 'src/app/models/user';

@Component({
  selector: 'app-view-register',
  templateUrl: './view-register.component.html',
  styleUrls: ['./view-register.component.css']
})
export class ViewRegisterComponent implements OnInit {

    private userDetails : IUser ;

  constructor(
    private userService : UserService
  ) { }

  ngOnInit() {

    let currentUser = this.userService.getCurrentUserId();
    if(currentUser === null ) {
      currentUser = localStorage.getItem("currentUserId");
    }
    this.userService.getRegisteredUser(currentUser).subscribe(
      res => {
        this.userDetails = res ;
      },
      err => {
        console.log("Error while fetching the Profile data")
      }
    )
  }

  onDestroy(){
    localStorage.clear();
  }

}
