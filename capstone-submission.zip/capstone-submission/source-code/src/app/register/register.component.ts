import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { IUser } from '../models/user';
import { UserService } from '../services/user/user.service';

@Component({
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  private registerForm: FormGroup;
  private submitted = false;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      id: '',
      username: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      location: ['', Validators.required],
      mobileNo: ['', [Validators.required, Validators.maxLength(10)]]
    });
  }

  get registerFormItems() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    if (this.registerForm.invalid) {
      return;
    }
    this.registerForm.patchValue({
      id: this.registerForm.controls['username'].value
    })

    this.userService.registerUser(this.registerForm.value).subscribe(
      (res) => {
        this.router.navigate(['login']);
      },
      (err) => console.log("User registered Has Failed")
    );



  }

}
