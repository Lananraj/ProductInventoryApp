import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductViewComponent } from './products-view/product-view.component';
import { ProductDetailViewComponent } from './product-detail-view/product-detail-view.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { AuthGuard } from '../guard/auth.guard';
import { ProductChartComponent } from './product-chart/product-chart.component';
import { CanDeactivateGuard } from '../guard/can-deactivate.guard';


const productRoutes: Routes = [
    { path: '', component: ProductViewComponent },
    { path: 'addProduct', component: AddProductComponent, canActivate: [AuthGuard] },
    { path: 'product-detail', component: ProductDetailViewComponent },
    { path: 'editProduct', component: EditProductComponent, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] },
    { path: 'chart', component: ProductChartComponent }
]
@NgModule({
    imports: [RouterModule.forChild(productRoutes)],
    exports: [RouterModule]
})
export class ProductRoutingModule {
}
export const productRoutingComponents = [ProductViewComponent, AddProductComponent]