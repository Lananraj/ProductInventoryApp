import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductRoutingModule } from './product-routing-module';
import { ProductService } from '../services/product/product.service';
import { AddProductComponent } from './add-product/add-product.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { EditProductComponent } from './edit-product/edit-product.component';
import { ProductViewComponent } from './products-view/product-view.component';
import { ProductDetailViewComponent } from './product-detail-view/product-detail-view.component';
import { AuthGuard } from '../guard/auth.guard';
import { SearchFilterPipe } from '../pipes/search-filter.pipe';
import { ProductChartComponent } from './product-chart/product-chart.component';
import { ChartsModule } from 'ng2-charts';
import { CanDeactivateGuard } from '../guard/can-deactivate.guard';


@NgModule({
  declarations: [
    ProductViewComponent, AddProductComponent,
    EditProductComponent, ProductDetailViewComponent,
    SearchFilterPipe,
    ProductChartComponent
  ],
  imports: [
    CommonModule,
    ProductRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    ChartsModule
  ],
  providers: [ProductService, AuthGuard, CanDeactivateGuard]
})
export class ProductModule { }