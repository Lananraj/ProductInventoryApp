import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { IProduct } from 'src/app/models/products';


@Component({
  selector: 'app-product-chart',
  templateUrl: './product-chart.component.html',
  styleUrls: ['./product-chart.component.css']
})
export class ProductChartComponent implements OnInit {

  chartData: IProduct[];
  barChartData: any[] = [];
  noOfProducts: number;

  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public mbarChartLabels: string[] = ['Top Viewd Products']
  public barChartType: string = 'bar';
  public barChartLegend: boolean = true;

  backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#CD5C5C", "#FFA500", "#228B22",
    "#008080", "#8B008B"]

  constructor(
    private productService: ProductService
  ) {

    this.productService.getProducts().subscribe(
      res => {
        this.chartData = res;
        this.chartData = this.chartData.sort(function (a, b) {
          return a.viewCount - b.viewCount
        });


        this.chartData.reverse();



      },
      err => {

      }
    )

  }
  ngOnInit() {

  }

  value = 5;

  onKey(event: any) {
    this.value = event.target.value;
    console.log("event value " + this.value)
    if (this.value > 0) {
      this.barChartData = [];
      for (var i = 0; i < this.value; i++) {
        this.barChartData.push({
          data: [this.chartData[i].viewCount],
          label: this.chartData[i].prodName
        })
      }
    }

  }


}

