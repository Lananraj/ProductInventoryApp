import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from 'src/app/services/product/product.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  editProductForm: FormGroup;
  private submitted = false;


  constructor(
    private formBuilder: FormBuilder,
    private productService: ProductService,
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.editProductForm = this.formBuilder.group(
      {
        id: '',
        prodName: ['', Validators.required],
        prodDescription: ['', Validators.required],
        prodManufact: ['', Validators.required],
        prodPrice: ['', Validators.required],
        prodQuantity: ['', Validators.required],
        viewCount: ''
      }
    )

    let productId: string = this.productService.getCurrentProductId();
    this.productService.getProductByID(productId).subscribe(
      res => {
        this.editProductForm.setValue(res)
        this.editProductForm.controls['id'].disable();
      },
      err => {
        console.log("Update product initialization is Failed")
      }
    )
  }

  get editProductFormItems() {
    return this.editProductForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    if (this.editProductForm.invalid) {
      return;
    }

    this.productService.updateProduct(this.productService.getCurrentProductId(), this.editProductForm.value).subscribe(
      res => {
        this.router.navigate(['products'])
      },
      err => {

      }
    )

  }

  canDeactivate(): boolean {
    console.log("inside  canDeactivate")
    if (this.editProductForm.dirty || this.editProductForm.touched) {
      let cancelFlag = confirm("Please confirm to Proceed");
      return cancelFlag;
    }
    else {
      return true;
    }

  }
  cancel() {
    let cancelFlag = confirm("Are you sure want to cancel?");
    if (cancelFlag === true) {
      this.router.navigate(['products']);
    }
  }

}
