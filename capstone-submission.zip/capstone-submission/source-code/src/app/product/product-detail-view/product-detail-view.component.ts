import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/models/products';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { ProductService } from 'src/app/services/product/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-detail-view',
  templateUrl: './product-detail-view.component.html',
  styleUrls: ['./product-detail-view.component.css'],
})
export class ProductDetailViewComponent implements OnInit {

  private productDetail: IProduct;

  constructor(
    private productService: ProductService,
    private router: Router
  ) {

  }

  ngOnInit() {
    let id: string = this.productService.getCurrentProductId();
    this.productService.getProductByID(id).subscribe(
      res => {
        this.productDetail = res;
      },
      err => {
        console.log("Product by id is failed");
      }
    );
  }

  onUpdateProduct() {
    this.router.navigate(['products/editProduct']);
  }

  onDeleteProduct(id: string) {
    if (localStorage.getItem("isLoggedIn") === "true") {

      this.productService.deleteProduct(id).subscribe(
        res => {
          this.router.navigate(['products']);
        },
        err => {
          console.log("Error in deletion")
        }
      )
    }
    else {
      let deleteFlag = confirm("Login required to perform this operation? Do you want to continue?");
      if (deleteFlag) {
        this.router.navigate(['login']);
      } else {
        return;
      }
    }
  }


}
