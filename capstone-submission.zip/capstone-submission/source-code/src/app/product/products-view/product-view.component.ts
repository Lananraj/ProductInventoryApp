import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/models/products';
import { ProductService } from 'src/app/services/product/product.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './product-view.component.html',
  styleUrls: ['./product-view.component.css']
})
export class ProductViewComponent implements OnInit {

  private products: IProduct[] = [];
  private productData: IProduct;

  constructor(
    private productService: ProductService,
    private router: Router
  ) { }

  ngOnInit() {

    this.productService.getProducts().subscribe(
      (res) => {
        this.products = res;
        console.log(res)
      },
      (err) => {
        console.log("Error has occurred while fetching the products")
      }
    );
  }


  onEditProduct(id: string) {
    console.log("Inside set id -->" + id)
    this.productService.setCurrentProductId(id)

    const promise = this.productService.getProductByID(id).toPromise();
    promise.then(
      (data) => {
        this.productData = data;
        data.viewCount++;
        const viewPromise = this.productService.updateProdViewDetails(id, this.productData).toPromise()
        viewPromise.then(
          (res) => {
            this.router.navigate(['products/product-detail'])
          })

      }
    )

  }

  onAddProduct() {
    this.router.navigate(['products/addProduct'])
  }
}
