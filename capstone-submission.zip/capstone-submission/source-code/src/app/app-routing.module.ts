import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AppComponent } from './app.component';
import { ViewRegisterComponent } from './register/view-register/view-register.component';
import { HomeComponent } from './home/home.component';
import { APP_BASE_HREF } from '@angular/common';
import { AboutComponent } from './about/about/about.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'refresh', component: AppComponent },
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'products', loadChildren: () => import(`./product/product.module`).then(m => m.ProductModule) },
  { path: 'profile', component: ViewRegisterComponent },
  { path: 'about', component: AboutComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const appRoutingComponents = [LoginComponent, RegisterComponent, ViewRegisterComponent]
