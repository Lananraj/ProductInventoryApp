import { Pipe, PipeTransform } from "@angular/core";
import { IProduct } from '../models/products';


@Pipe({
    name: 'searchFilter'
})

export class SearchFilterPipe implements PipeTransform {

    transform(products: IProduct[], filterKeyword: string) {
        if (!products || !filterKeyword) {
            return products;
        }
        return products.filter(
            products => products.prodName.toLowerCase().indexOf(filterKeyword.toLowerCase()) !== -1);
    }
}